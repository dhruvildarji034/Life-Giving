// import rose from './images/rose.jpg';
// import alovera from './images/alovera.jpg';
// import cactus from './images/cactus.jpg';
// import guava from './images/guava.jpg' 
// import React from 'react';
// import './Imagegallary.css';
// import moneyvale from './images/moneyvale.jpg'
// import tulsi from './images/tulsi.jpg';
// import sunflower from './images/sunflower.jpg' 
// import polyalthia from './images/polyalthia.jpg'; 


// function Imagegallary() {
//     const imagess =[
//         {name:"Alovera",
//         image:rose,
//         category:"one",
//         Desc:"Aloe vera is a succulent plant species of the genus Aloe. It is widely distributed,and is considered an invasive species in many world regions."
//       },
//       {name:"Cactus",
//         image:alovera,
//         category:"one",
//         Desc:"Aloe vera is a succulent plant species of the genus Aloe. It is widely distributed,and is considered an invasive species in many world regions."
//       },
//       {name:"Bonsai ",
//         image:cactus,
//         category:"two",
//         Desc:"Aloe vera is a succulent plant species of the genus Aloe. It is widely distributed,and is considered an invasive species in many world regions."
//       },
//       {name:"Guava",
//         image:guava,
//         category:"two",
//         Desc:"Aloe vera is a succulent plant species of the genus Aloe. It is widely distributed,and is considered an invasive species in many world regions."
//       },
//       {name:"Moneyvale",
//         image:moneyvale,
//         category:"two",
//         Desc:"Aloe vera is a succulent plant species of the genus Aloe. It is widely distributed,and is considered an invasive species in many world regions."
//       },
//       {name:"Tulsi",
//         image:tulsi,
//         category:"two",
//         Desc:"Aloe vera is a succulent plant species of the genus Aloe. It is widely distributed,and is considered an invasive species in many world regions."
//       },
//       {name:"Polyalthia",
//         image:polyalthia,
//         category:"one",
//         Desc:"Aloe vera is a succulent plant species of the genus Aloe. It is widely distributed,and is considered an invasive species in many world regions."
//       },
//       {name:"Sunflower",
//         image:sunflower,
//         category:"one",
//         Desc:"Aloe vera is a succulent plant species of the genus Aloe. It is widely distributed,and is considered an invasive species in many world regions."
//       }
//       ]
//       function renderGallery(filteredImages) {
//         const galleryDiv = document.getElementById('gallery');
//         const galleryHTML = filteredImages.map((value) => (
//           `<div class="dd" key=${value.name}>
//             <img src=${value.image} height="250px" width="200px" alt="logo" />
//             <h3>${value.name}</h3>
//             <p>Desc: ${value.Desc}</p>
//             <p>Category: ${value.category}</p>
           
 
//           </div>`
//         )).join('');
//         galleryDiv.innerHTML = galleryHTML;
//       }
    
//       function all() {
//         renderGallery(imagess);
//       }
    
//       function one() {
//         const oneImagess = imagess.filter(image => image.category === "one");
//         renderGallery(oneImagess);
//       }
    
//       function two() {
//           const twoImagess = imagess.filter(image => image.category === "two");
//         renderGallery(twoImagess);
//       }
//       React.useEffect(() => {
//         renderGallery(imagess);
// },[]);
// return (
// <div className='theother' >
          
//           <div className='imagess'>
//             <button onClick={all}>All</button>
//             <button onClick={one}>ONE</button>
//             <button onClick={two}>TWO</button>
//           </div>
//           <div className='cc' id="gallery"> </div>
//         </div>
//       );
//     }
    
//     export default Imagegallary;




import React, { useState, useEffect } from 'react';
import rose from './images/rose.jpg';
import alovera from './images/alovera.jpg';
import cactus from './images/cactus.jpg';
import guava from './images/guava.jpg';
import moneyvale from './images/moneyvale.jpg';
import tulsi from './images/tulsi.jpg';
import sunflower from './images/sunflower.jpg';
import polyalthia from './images/polyalthia.jpg';
import './Imagegallary.css';

function Imagegallary() {
  const initialImages = [
    {
      name: "Alovera",
      image: alovera,
      category: "Nonflowering",
      desc: "Aloe vera is a succulent plant species of the genus Aloe. It is widely distributed, and is considered an invasive species in many world regions."
    },
    {
      name: "Cactus",
      image: cactus,
      category: "Nonflowering",
      desc: "Cacti are succulent plants that thrive in arid regions and are known for their unique appearance and resilience."
    },
    {
      name: "Bonsai",
      image: rose,
      category: "Nonflowering",
      desc: "Bonsai is a Japanese art form using cultivation techniques to produce small trees in containers that mimic the shape and scale of full-size trees."
    },
    {
      name: "Guava",
      image: guava,
      category: "flowering",
      desc: "Guava is a tropical fruit native to Mexico, Central America, and northern South America."
    },
    {
      name: "Moneyvale",
      image: moneyvale,
      category: "Nonflowering",
      desc: "Moneyvale is known for its lush, green foliage and is often kept as an indoor plant."
    },
    {
      name: "Tulsi",
      image: tulsi,
      category: "flowering",
      desc: "Tulsi, also known as Holy Basil, is a revered plant in India known for its medicinal properties."
    },
    {
      name: "Polyalthia",
      image: polyalthia,
      category: "flowering",
      desc: "Polyalthia is a genus of flowering plants, known for their diverse forms and uses in traditional medicine."
    },
    {
      name: "Sunflower",
      image: sunflower,
      category: "flowering",
      desc: "Sunflowers are large, bright flowers known for their beauty and for producing sunflower seeds and oil."
    }
  ];

  const [images, setImages] = useState(initialImages);
  const [cart, setCart] = useState(() => {
    const initialCart = {};
    initialImages.forEach(image => {
      initialCart[image.name] = 0;
    });
    return initialCart;
  });

  const addToCart = (name) => {
    setCart(prevCart => ({
      ...prevCart,
      [name]: prevCart[name] + 1
    }));
  };

  const removeFromCart = (name) => {
    setCart(prevCart => ({
      ...prevCart,
      [name]: prevCart[name] > 0 ? prevCart[name] - 1 : 0
    }));
  };

  const renderGallery = (filteredImages) => {
    return filteredImages.map((value) => (
      <div className="dd" key={value.name}>
        <img src={value.image} height="250px" width="200px" alt={value.name} />
        <h3>{value.name}</h3>
        <p>{value.desc}</p>
        <p>Category: {value.category}</p>
        <div className="cart-buttons">
          <button onClick={() => addToCart(value.name)}>+</button>
          <button onClick={() => removeFromCart(value.name)}>-</button>
        </div>
        <div className='qcart'><p>Quantity in Cart: {cart[value.name]}</p></div>
        
      </div>
    ));
  };

  const all = () => setImages(initialImages);

  const flowering = () => setImages(initialImages.filter(image => image.category === "flowering"));
  
  const Nonflowering = () => setImages(initialImages.filter(image => image.category === "Nonflowering"));

  useEffect(() => {
    renderGallery(images);
  }, [images, cart]);

  return (
    <div className='theother'>
      <div className='imagess'>
        <button onClick={all}>All</button>
        <button onClick={flowering }>flowering </button>
        <button onClick={Nonflowering }>Nonflowering </button>
      </div>
      <div className='cc' id="gallery">
        {renderGallery(images)}
      </div>
    </div>
  );
}

export default Imagegallary;
