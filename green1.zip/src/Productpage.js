import React from 'react';
import Imagegallary from './Imagegallary';

const Contact = () => {
  return (
    <div>
      <h1>"Grow Your Happiness"</h1>
      <Imagegallary/>
    </div>
  );
};

export default Contact;