import React from 'react';
import  { useState, useEffect } from 'react';
import './Imagegallary';

import './Home.css';

const Home = () => {
  const facts = [
    "Trees are the longest living organisms on Earth.",
    "A mature leafy tree produces as much oxygen in a season as 10 people inhale in a year.",
    "Trees can communicate with each other through underground networks of fungi.",
    "Over 60,000 different tree species exist in the world.",
    "Many plants have medicinal properties.",
    "The world's smallest flowering plant is the watermeal (Wolffia spp.), which is about the size of a grain of rice.",
    "The world's tallest tree is a coast redwood in California, measuring over 379 feet tall.",
    "Orchids have the largest variety of flowers, with over 25,000 documented species.",
    "Aloe vera plants contain a gel that is commonly used to soothe burns and skin irritations.",
    "Tropical forests alone produce over 40% of the oxygen we breathe.",
    "Recent research has found that plant roots can respond to environmental sounds.",
    "Baobab trees can store thousands of liters of water in their trunks."
  ];

  const [currentFact, setCurrentFact] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentFact((prevFact) => (prevFact + 1) % facts.length);
    }, 5000); // 15000 milliseconds = 15 seconds

    return () => clearInterval(intervalId); // Cleanup the interval on component unmount
  }, [facts.length]); 

  

  return (
    <>
      <div className='facts'>
            <h1>Did you know?</h1>
            <p>"{facts[currentFact]}"</p>
      </div>
      <div className='theother'>
        <div className='bgimage' ></div>
        <div className='commain'>
          <div className='community'></div>
          <div class="community-section">
          <h1>Join Our Community</h1>
          <p>We believe in the power of community and the joy of sharing knowledge and experiences. Join us on social media to stay updated on the latest plant trends, care tips, and special offers. Whether you’re a seasoned gardener or a plant novice, you’ll find a welcoming community ready to help you grow.</p>
          </div>
      </div>
      <div className='whyusmain'>
        <div className='whyus'></div>
          <div class="whyus-section">
          <h1>Why Choose Us?</h1>
        </div>    <div className='cardmain'>
                  <div class="card">
                    <div class="container">
                    <h4><b>Quality Assurance</b></h4>
                    <p> Every plant we sell is handpicked and thoroughly inspected to ensure it meets our high standards of health and beauty.</p>
                    </div>          
                  </div>
                  <div class="card">
                    <div class="container">
                    <h4><b>Expert Guidance</b></h4>
                    <p>Our team of plant enthusiasts is always ready to offer advice and tips to help you select the perfect plant and care for it properly.</p>
                    </div>          
                  </div>
                  <div class="card">
                    <div class="container">
                    <h4><b>Sustainability</b></h4>
                    <p>We are committed to environmentally friendly practices, using sustainable packaging and promoting green living.</p>
                    </div>          
                  </div>
                  <div class="card">
                    <div class="container">
                    <h4><b>Customer Satisfaction</b></h4>
                    <p>Your satisfaction is our priority. We provide excellent customer service and a guarantee on all our plants.</p>
                    </div>          
                  </div> 
                  </div> 
                  
        
      </div>     
    </div>
        
    </>
  );
};

export default Home;